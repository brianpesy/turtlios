/*
 This is a course requirement for CS 192 Software Engineering II
 under the supervisino of Asst. Prof. Ma. Rowena C. Solamo
 of the Department of computer Science, College of Engineering,
 University of the Philippines, Diliman
 for the AY 2017-2018
 
 This code is created by Joan Nicole Balugay and Brian Sy.
 
 
 Code History
 Programmer           Date       Description
 Brian Sy             01/29/18   Creation
 Joan Nicole Balugay  01/29/18   Creation
 
 File Creation Date: 01/29/118
 Development Group: Joan Nicole Balugay, Brian Sy
 Client Group: CS 192
 Purpose of the Software: Note taking application - Turtl
 */

import XCTest
@testable import Turtl

class TurtlTests: XCTestCase {

    /*Put setup code here. This method is called before the invocation of each test method in the class.*/
    override func setUp() {
        super.setUp()
    }
    /*Put teardown code here. This method is called after the invocation of each test method in the class*/
    
    override func tearDown() {
        super.tearDown()
    }
    
    /* This is an example of a functional test case. Use XCTAssert and related functions to verify your tests produce the correct results.*/
    func testExample() {
        
    }
    /*This is an example of a performance test case.*/
    func testPerformanceExample() {

        /*Put the code you want to measure the time of here.*/
        self.measure {

        }
    }
    
}
